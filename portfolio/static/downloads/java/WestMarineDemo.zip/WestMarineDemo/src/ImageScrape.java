
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class ImageScrape {
	private static ArrayList<refPair> list;
	
	public static void main(String[] args) throws MalformedURLException {
		
		
		String extension = ".jpg";
		Scanner stdin = new Scanner(System.in);
		System.out.printf("Enter URL to scrape (e.g. http://catalog.seastarsolutions.com/productImages/ ): ");
		String toParse = stdin.next();
		
		
		
//		while (stdin.hasNextLine()) {
//			String s = stdin.next();
//			String u = toParse + s + extension;
//			URL url = new URL(u);
////			System.out.println(url);
//			try {
//				scrapify(url, s);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
		
		ImportCSV file = new ImportCSV();
		ArrayList<refPair> refList = new ArrayList<refPair>();
		System.out.println("Which reference list would you like to use?: ");
		list = file.Import(stdin.next());
//		System.out.println(list.size());
		
		for(int i = 0; i < list.size(); i++) {
			String s = toParse + list.get(i).mfg + extension;
			URL url = new URL(s);
			try {
				scrapify(url, list.get(i).sku);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		

	}
	
	private static void scrapify(URL url, String name) throws IOException{
		
		InputStream in = new BufferedInputStream(url.openStream());
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		int n = 0;
		try {
			while (-1!=(n=in.read(buf)))
			{
			   out.write(buf, 0, n);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		 out.close();
		 in.close();
		 byte[] response = out.toByteArray();
			
		 FileOutputStream fos = new FileOutputStream("S:/eCommerce/SKU Publishing/009 - Electrical/Images/Blue Sea Systems/AllImages/"+name+".jpg");
		 fos.write(response);
	   	 fos.close();
		}

}
