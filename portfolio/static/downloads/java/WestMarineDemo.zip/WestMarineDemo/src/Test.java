import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;




public class Test {
	private static final String USER_AGENT =
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1";
	public WebDriver driver = new FirefoxDriver();
	
	public void openTestSite() {
		driver.navigate().to("http://testing-ground.scraping.pro/login");
	}
	
	public void getText() throws IOException {
		String text = driver.findElement(By.xpath("//div[@id='case_login']/h3")).getText();
		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("status.txt"), "utf-8"));
		writer.write(text);
		writer.close();

	}
	
	
	public static void main(String[] args) {
		
		
		String url = "http://www.ancorproducts.com/en/552830";
		
		//company name test
//		String[] sansWWW = url.split("www."); //so we can split something ie "w" into [0]
//		String[] sansCOM = sansWWW[1].split(".com");
//		String companyName = sansCOM[0];;
//		System.out.println(companyName);		
		
		//This is my attempt to grab the page fully rendered
		//using WebClient which would load all of the js before
		//converting it to a Document object from jsoup
	
		//if you didn't update the Path system variable to add the full directory path to the executable as above mentioned then doing this directly through code
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		
			
			WebDriver driver = new ChromeDriver();
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			driver.navigate().to(url);
			try {
				Thread.sleep(5000L);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Document docOverview = Jsoup.parse(driver.findElement(By.id("pagecontentarea_0_maincontentarea_0_ctl01_Overview")).getAttribute("innerHTML").toString());
			Elements prodName = docOverview.select("h2");
			Elements prodMfg = docOverview.select("span");
			Elements overview = docOverview.select("#pagecontentarea_0_maincontentarea_0_ctl01_ctl00_dvLeftDesc");
			System.out.println(prodName.text());
			System.out.println(prodMfg.text());
			System.out.println(overview.text());
			
			driver.findElement(By.id("pagecontentarea_0_maincontentarea_0_ctl01_liPhysicalSpec")).click();
			try {
				Thread.sleep(5000L);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
			Document docPhysicalSpecs = Jsoup.parse(driver.findElement(By.id("PhysicalSpec")).getAttribute("innerHTML").toString());
			Elements physicalSpecsLabel = docPhysicalSpecs.select("div.DataGridLabel");
			Elements physicalSpecsValue = docPhysicalSpecs.select("div.DataGridValue");
			String [] specData = new String[physicalSpecsLabel.size()];
			int count = 0;
			for (Element element : physicalSpecsLabel ) {
				specData[count] = element.text() +": " + physicalSpecsValue.get(count).text();
				count++;
			}
			
			System.out.println(Arrays.toString(specData));
			
			driver.close();
			
//			System.out.println(text);
//			Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("status.txt"), "utf-8"));
//			writer.write(text);
//			writer.close();
//			
//			driver.close();
//		}
			
			//dont think we need this now that we are using HtmlPage to get unloaded js
//			Connection connection = Jsoup.connect(url).userAgent(USER_AGENT);
//			System.out.println("We got a web page at " + url);
			
//			if (myPage.getWebResponse().getStatusCode() == 200){ // 200 is the HTTP OK status code
//			    // indicating that everything is great
//			System.out.println("\n**Visiting** \nCurrently at web page " + url);
//			}
//			
//			if (!myPage.getWebResponse().getContentType().contains("text/html")) {
//			System.out.println("**Failure** Retrieved something other than HTML");
//				return;
//			}
//			if (myPage.getWebResponse().getStatusCode() != 200){ // 404 is the not found code
//			    // indicating that everything is great
//			System.out.println("\n this mfg doesn't exist" + url);
//				return;
//			}
			
			//convert to jsoup doc
//			Document htmlDocument = Jsoup.parse(myPage.asXml());
			
			
			/******************************************************************
			 * ****************************************************************
			 * This way vvvvvvvvv is the working way for static HTML
			 * ****************************************************************
			 */
			
			
//			Connection connection = Jsoup.connect(url).userAgent(USER_AGENT);
//			Document htmlDocument = connection.get();
//			//System.out.println("We got a web page at " + url);
//			
//			if (connection.response().statusCode() == 200){ // 200 is the HTTP OK status code
//			    // indicating that everything is great
//			System.out.println("\n**Visiting** \nCurrently at web page " + url);
//			}
//			
//			if (!connection.response().contentType().contains("text/html")) {
//			System.out.println("**Failure** Retrieved something other than HTML");
//				String[] failed = null;
//				return;
//			}
//			if (connection.response().statusCode() != 200){ // 404 is the not found code
//			    // indicating that everything is great
//			System.out.println("\n this mfg doesn't exist" + url);
//				String[] failed = null;
//				return;
//			}
			
			
//			//select the <div id=product_overview>
//			Elements overview = htmlDocument.select("#pagecontentarea_0_maincontentarea_0_ctl01_Overview > h2"); //for product description
//			Elements physicalSpecs = htmlDocument.select("#pagecontentarea_0_maincontentarea_0_ctl01_dvPhysicalSpec");//for spec
//			Elements techData = htmlDocument.select("#pagecontentarea_0_maincontentarea_0_ctl01_dvTechData"); //for spec value
//			
//			//combine our table data to an arraylist so we can print it easier 
//		System.out.println(overview.text());
//		System.out.println(physicalSpecs);
//		System.out.println(techData);	
//		
//	
//		}
//		catch(IOException ioe){
//            //We were not successful in our HTTP request
//		 	System.out.println(ioe);
//		 	System.out.printf("couldn't request %s/n", url );
//		}

	}
}
