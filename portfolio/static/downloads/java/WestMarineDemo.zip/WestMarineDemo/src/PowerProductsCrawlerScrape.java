import java.util.ArrayList;
import java.util.Scanner;

/**
 * PowerProductsCrawlerScrape was isolated from a more robust
 * program that I worked on at my time at West Marine. That
 * program runs for West Marine to update WestMarine.com and
 * WestMarinePro.com with vendor content.
 * 
 * This modified program takes a starting point URL from user input, a filename
 * from user input that creates a manufacture number (mfg) and west marine sku
 * number key value pair object (refPair). It then uses a Breadth First Search to
 * effectively crawl the designated site (in testing, DFS was not optimal)
 * looking for a Product Display Page by parsing the HTML then iterating through
 * to find a unique value for which a PDP is associated with. When it finds a PDP, 
 * it opens a webdriver to load all necessary JS to expose data to scrape. If the 
 * PDP then has a mfg that is a valid West Marine product, it scrapes the data and 
 * highest res image available, writes the data to an excel doc, renames the image 
 * in the file format designated for west marine's Hybris Platform, and writes the
 * content it into a specified location.
 * 
 * This program varies from the production version by
 * 
 * A) Taking user input from STDIN - The WM production version takes in
 * a list of product vendor pages and all current west marine SKUs with 
 * related mfg number.
 * 
 * B) Only works for web sites in the Power Products family - The WM production
 * version will have a different ***Crawler.java and ***CrawlerLeg.java depending
 * on which vendor site we are looking for content from.
 * 
 * C) Stores file to a local drive - The WM Production writes it's data to a 
 * hot folder associated with our SAP Hybris backend.
 * 
 * Uses Jsoup, Selenium WebDriver, OpenCV, and a host of other jars including a few
 * Apache jars.
 * 
 * @author ChrisJacobs
 * @updated January 2018
 */

public class PowerProductsCrawlerScrape {
	
	private static ArrayList<refPair> list;
	
	public static void main(String[] args) {
		
		//for custom input
		
		//url to start crawling site
		Scanner stdin = new Scanner(System.in);
		System.out.printf("Enter URL to scrape (e.g. http://www.ancorproducts.com/en/products ): ");
		String toSearch = stdin.next();
		
		//create list of refPair objects to use for checking and naming
		System.out.printf("Enter csv to use as key value reference list: ");
		String csvFileName = stdin.next();
		ImportCSV temp= new ImportCSV();
		list = temp.Import(csvFileName);
	
		
			//initiate crawl at given url
			PowerProductsCrawler crawler = new PowerProductsCrawler();
			crawler.search(toSearch, list);
	}	
}
		



