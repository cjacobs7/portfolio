/*
 * Simple helper object for ImportCSV to give us a mfg and sku 
 * key value pair
 * 
 * @author ChrisJacobs
 * @updated January 2018
 * 
 */

public class refPair {
	public String mfg;
	public String sku;
	
	public refPair(String mfg, String sku){
		this.mfg = mfg;
		this.sku = sku;
	}
	
	public String toString() {
		String s = "";
		s = mfg +", " + sku;
		return s;
	}
	
	public String getMfg() {
    	return mfg;
    }
	
	public String getsku() {
    	return sku;
    }
}
