
/*
 * Helper object for storing data found on PDP.
 * 
 * @author ChrisJacobs
 * @updated January 2018
 * 
 */

public class PowerProductsData {
	private String mfg;
	private String ProductDetails;
	private String ProductSpecs;
	
	public PowerProductsData() {
		mfg = "0";
		ProductDetails = "0";
		ProductSpecs = "0";
		
	}
	public PowerProductsData(String mfg, String ProductDetails, String Specs){
		this.mfg = mfg;
		this.ProductDetails = ProductDetails;
		this.ProductSpecs = Specs;
	}
	
	public void setMfg(String str){
		mfg = str;
	}
	public void setProductDetails(String str){
		ProductDetails = str;
	}
	
	public void setProductSpecs(String str){
		ProductSpecs = str;
	}
	
	public String getMfg(){
		return mfg;
	}
	public String getProductDetails(){
		return ProductDetails;
	}
	
	public String getProductSpecs(){
		return ProductSpecs;
	}
	
	@Override
	public String toString(){
		String toPrint = mfg + ", " + ProductDetails + ", " + ProductSpecs;
		return toPrint;
	}
	
}
