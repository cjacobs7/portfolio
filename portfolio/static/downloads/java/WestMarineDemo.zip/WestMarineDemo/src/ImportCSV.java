import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * ImportCSV is a custom import for our key value pair of 
 * the manufacture number (mfg) and correlated West Marine
 * sku (sku) to make an ArrayList of refPair objects.
 * 
 * This helps us correlated the found mfg to the wm sku
 * in order to format our image filename for Hybris
 * 
 * @author ChrisJacobs
 * @updated January 2018
 * 
 */



public class ImportCSV {
	
	//make private if ever running not on this comp;
	public int size;
	public ArrayList lines;
	
    public ArrayList<refPair> Import(String fileName) {
//        String fileName= "read_ex.csv";
        File file= new File(fileName);

        // this gives you a 2-dimensional array of strings
        lines = new ArrayList<>();
        Scanner inputStream;

        try{
            inputStream = new Scanner(file);
            while(inputStream.hasNext()){
                String line= inputStream.next();
                String[] values = line.split(",");
                // this adds the currently parsed line to the 2-dimensional string array
                refPair ref= new refPair(values[0], values[1]);
                lines.add(ref);
                size++;
            }

            inputStream.close();
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        return lines;
    }
    
    public String toString() {
    	for(int i = 0; i < size; i++) {
    		System.out.print(lines.get(i));
    	}
    	return null;
    }
    
}