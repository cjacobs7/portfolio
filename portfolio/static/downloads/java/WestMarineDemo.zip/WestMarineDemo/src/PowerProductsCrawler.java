
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/** 
 * PowerProductsCrawler is the Data Structure responsible
 * for the order of the site being crawled.
 * 
 * It uses a BFS to crawl the site, grabbing links and information
 * about the page via PowerProductsCrawlerLeg.java.
 * 
 * When it finds a PDP, it opens a webdriver, loads the JS,
 * reads and writes the content (data and images) to the pre-designated
 * location. 
 * 
 * This program varies from the production version by:
 * A) including the reading and writing of the image/data -
 * the production version is more modular. This was changed 
 * for simplicity in this version
 * 
 * B) Writes our data to an Excel file and image to a local folder -
 * the production version writes the data to our SAP Hybris platform
 * 
 * @author ChrisJacobs
 * @updated January 2018
 * 
 */

public class PowerProductsCrawler {
	private static final int MAX_PAGES = 7500; //page visits until it gives up looking
	private Set<String> pagesVisited = new HashSet<String>(); //marked visited as we do BFS (Queue)
	private LinkedList<String> pagesToVisit = new LinkedList<String>(); //BFS Queue
	private static final String USER_AGENT =
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1";
	private int rowCount;
	private ArrayList<refPair> list;
	private int mfgIndex;
	
	
	/**
	 * Search the Url by starting at URL at top of Queue, parsing html,
	 * then looking for searchword and exporting wmSKU with it so we can name it
	 * 
	 * @param String url
	 * @param ArrayList<refPair> refList
	 * 
	 */
	
	public void search(String url, ArrayList<refPair> refList){
		
		//let refFlist become global
		this.list=refList;
		
		//set a mad number of pages in case we get stuck in loop
		while(this.pagesVisited.size() < MAX_PAGES){
			//for visual reference
			System.out.printf("%d pages visited\n", pagesVisited.size());
			String currentUrl;
			PowerProductsCrawlerLeg leg = new PowerProductsCrawlerLeg();
			
			//first page case
			if(this.pagesToVisit.isEmpty()) {
				currentUrl = url.replaceAll("%20", " ");
				this.pagesVisited.add(url);
			}
			else {
				//format for spaces in url from parse
				currentUrl = this.nextURL().replaceAll("%20", " ");
			}
			
			//execute crawl over page
			try {
				leg.crawl(currentUrl);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			System.out.printf("Pages in Queue %d\n", pagesToVisit.size());
			
			//Send searchWord to crawlerleg which parses html to scan that url being searched
			//we use something really specific so we know we're on a PDP vendor page for 
			//for this specific vendor. We can't use the mfg because it might exist somewhere
			//else on the site on a non PDP
			boolean success = leg.isPDP("pagecontentarea_0_maincontentarea_0_ctl01_ctl00_dvLeftDesc");
			if (success == true) {
					//we've found a pdp from criteria in isPDP()
					
					//initialize str array for data output
					String[] toWrite = new String[5];
					
					rowCount++; //keep track of how many rows to write
					toWrite = getData(currentUrl);
					
					//check if mfg is an mfg west marine carries
					boolean isWmProduct = isWmProduct(toWrite[1]);
					if(isWmProduct == true) {
					
					String imgToAppend = "";
						try {
							Document doc;
							doc = Jsoup.connect(currentUrl).get();
						
							//grab the div with our src in it
							Elements linksOnPage = doc.select("div.ProductDetailImg");
						
							//image src from the div header 
							//using regex string splits
							String target = linksOnPage.toString();
							String[] tempSplit = target.split("zoomSrc=");
							String[] imgSrc = tempSplit[1].split("\" src=\"");
							
							//format url splitting on last backslash
							int lastIndex = url.lastIndexOf("/");
							String[] origUrl = {url.substring(0, lastIndex), url.substring(lastIndex)};
							
							//parse image source
							imgToAppend = origUrl[0] + imgSrc[0].substring(1, imgSrc[0].length());
							System.out.println(imgToAppend);
							
							//grab images with source url
							getImages(imgToAppend, list.get(mfgIndex).getsku());
							write(toWrite);
						}
						catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.printf("**Success** This was a PDP and we grabbed the content\n");
					}
				} 
			
			this.pagesToVisit.addAll(leg.getLinks());
		}
		
		System.out.printf("Visited %d", this.pagesVisited.size());
	}
	
	
	/*
	 * nextURL iterates through our queue to grab the next 
	 * url and remove the the url we just visited
	 */
	private String nextURL() {
		String nextUrl;
	      do{
	          nextUrl = this.pagesToVisit.remove(0);
	      } 
	      while(this.pagesVisited.contains(nextUrl));
	      
	      this.pagesVisited.add(nextUrl);
	      return nextUrl;
	     
	}
	
	/*
	 * isWmProduct searches our Arraylist of refPairs
	 * for a given mfg to return a boolean
	 * 
	 * @param String mfg
	 */
	
	private boolean isWmProduct(String mfg) {
		boolean isProduct = false;
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).getMfg().equals(mfg)){
				mfgIndex = i;
				isProduct = true;
				break;
			}
		}
		
		return isProduct;
	}
	
	/**
	 * This method takes in a url specific to power products that is a source url for an image
	 * on the page we found the mfg on.
	 * 
	 * getImages takes in a String as a source URL and WMSKU what we want to name 
	 * the file and saves it to a manual folder 
	 * 
	 * @param String src
	 * @param String wmSKU
	 * @throws IOException
	 */
	private static void getImages(String src, String wmSKU) throws IOException {
		
		//this is a roundabout way of getting around a 403 error
		URLConnection connection = new URL(src).openConnection();
		connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
		connection.connect();
		InputStream in = new BufferedInputStream(connection.getInputStream());
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		int n = 0;
		try {
			while (-1!=(n=in.read(buf)))
			{
			   out.write(buf, 0, n);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		 out.close();
		 in.close();
		 byte[] response = out.toByteArray();
			
		 FileOutputStream fos = new FileOutputStream("S:/eCommerce/SKU Publishing/009 - Electrical/Images/Ancor/AllImages/"+wmSKU+".jpg");
		 fos.write(response);
	   	 fos.close();
		}
		
	/**
	 * Takes in a URL in the form of a string and will
	 * grab the table data present on the PDP
	 * 
	 * Uses webdriver to open up the page, make a click to the tab that's loaded
	 * with JavaScript then scrape
	 * 
	 * String[1] = product mfg
	 * 
	 * @param String url
	 * @return stringArray to add two our 2x2 to eventually write
	 */
	
	private static String[] getData(String url) {
		//rowToWrite will pass our data to a 2x2 to write
		String[] rowToWrite = new String[5];
		
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.navigate().to(url);
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Document docOverview = Jsoup.parse(driver.findElement(By.id("pagecontentarea_0_maincontentarea_0_ctl01_Overview")).getAttribute("innerHTML").toString());
		Elements prodName = docOverview.select("h2");
		Elements prodMfg = docOverview.select("span");
		Elements overview = docOverview.select("#pagecontentarea_0_maincontentarea_0_ctl01_ctl00_dvLeftDesc");
		
		rowToWrite[1] = prodMfg.text();
		rowToWrite[2] = prodName.text();
		rowToWrite[3] = overview.text();
		
		driver.findElement(By.id("pagecontentarea_0_maincontentarea_0_ctl01_liPhysicalSpec")).click();
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		Document docPhysicalSpecs = Jsoup.parse(driver.findElement(By.id("PhysicalSpec")).getAttribute("innerHTML").toString());
		Elements physicalSpecsLabel = docPhysicalSpecs.select("div.DataGridLabel");
		Elements physicalSpecsValue = docPhysicalSpecs.select("div.DataGridValue");
		String [] specData = new String[physicalSpecsLabel.size()];
		int count = 0;
		
		//format gridlabels and gridvalues
		for (Element element : physicalSpecsLabel ) {
			specData[count] = element.text() +": " + physicalSpecsValue.get(count).text();
			count++;
		}
		
		rowToWrite[4] = Arrays.toString(specData);
		
		
		
		driver.close();
		
		return rowToWrite;
	}
	
	/*
	 * Write will take a str array input and write it
	 * out to an excel doc. Check Filepath, must be valid
	 * destination.
	 *
	 * @param String[] row 
	 */
	
	public void write(String[] row) {
		try {
		FileInputStream fsIP= new FileInputStream(new File("S:/eCommerce/SKU Publishing/009 - Electrical/Images/Ancor/AllImages/AncorData.xlsx"));  
		//Access the workbook                  
		XSSFWorkbook wb = new XSSFWorkbook(fsIP);
		//Access the worksheet, so that we can update / modify it. 
		XSSFSheet worksheet = wb.getSheetAt(0); 
		// declare a Cell object
		Cell cell = null; 
		// Access the second cell in second row to update the value
		
		Row newRow = worksheet.createRow(rowCount);
		cell = newRow.createCell(0);   
		cell.setCellValue(row[0]);
		cell = newRow.createCell(1);  
		cell.setCellValue(row[1]); //in getData we kept [0] empty in case we wanted to place the wmSKU in there in the future
		cell = newRow.createCell(2);   
		cell.setCellValue(row[2]);
		cell = newRow.createCell(3);  
		cell.setCellValue(row[3]);
		cell = newRow.createCell(4);   
		cell.setCellValue(row[4]);
		//Close the InputStream  
		
		fsIP.close();
		//Open FileOutputStream to write updates
		FileOutputStream output_file =new FileOutputStream(new File("S:/eCommerce/SKU Publishing/009 - Electrical/Images/Ancor/AllImages/AncorData.xlsx"));  
			//write changes
		wb.write(output_file);
		//close the stream
		output_file.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
}

